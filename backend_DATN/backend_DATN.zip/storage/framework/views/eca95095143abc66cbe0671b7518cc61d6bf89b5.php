<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Sendmaildangky</title>
    <style>
        body{
            padding: 50px 500px 50px 500px;
        }
        .table{
            /* background-color: aliceblue;
            height: 550px;
            width: 650px; */
            padding: 12px 12px 12px 12px;
        }
        .header{
            text-align: center;
        }
        .body h2{
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="table">
    <div class="header">
    <h1>GỬI HÓA ĐƠN HÀNG THÁNG</h1>
    
    </div>
    <div class="body">
        
        <b>Hello, bạn <?php echo e($user->full_name); ?> </b>
        <p>Gửi hóa đơn tháng vừa rồi</p>
        <p>Tiền điện: <?php echo e(number_format($user->electricity_money)); ?>đ</p>
        <p>Tiền nước: <?php echo e(number_format($user->water_money)); ?></p>
        <p>Tiền thuê: <?php echo e(number_format($user->room_price)); ?>đ</p>
        <p>Tổng: <?php echo e(number_format($user->all_money)); ?>đ</p>
        <p>Nhấp <a href="https://timtrosinhvien.com/login">vào đây</a> để đăng nhập vào tài khoản.</p>  
    </div>
    <div class="footer">
        <p>Thân,<br>
        Nhà Tui</p>
    </div>
    </div>
</body>
</html><?php /**PATH C:\Users\admin\OneDrive\Máy tính\FPT Polytechnic\7. Đồ án tốt nghiệp\DATN\backend_DATN\resources\views/email/SendmailBill.blade.php ENDPATH**/ ?>