<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Sendmaildangky</title>
    <style>
        body{
            padding: 50px 500px 50px 500px;
        }
        .table{
            /* background-color: aliceblue;
            height: 550px;
            width: 650px; */
            padding: 12px 12px 12px 12px;
        }
        .header{
            text-align: center;
        }
        .body h2{
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="table">
    <div class="header">
    <h1>TRẢ PHÒNG KHÔNG THÀNH CÔNG</h1>
    
    </div>
    <div class="body">
        
        <b>Hello, bạn <?php echo e($user->full_name); ?> </b>
        <p>Bạn vừa gửi yêu cầu trả phòng không thành công</p>
        <p>Nhấp <a href="https://timtrosinhvien.com/login">vào đây</a> để xem chi tiết</p>
        
    </div>
    <div class="footer">
        <p>Thân,<br>
        Nhà Tui</p>
    </div>
    </div>
</body>
</html><?php /**PATH C:\Users\admin\OneDrive\Máy tính\FPT Polytechnic\7. Đồ án tốt nghiệp\DATN\backend_DATN\resources\views/email/SendMailCheckOutAlertUnSuccess.blade.php ENDPATH**/ ?>